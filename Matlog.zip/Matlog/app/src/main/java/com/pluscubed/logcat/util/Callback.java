package com.pluscubed.logcat.util;

public interface Callback<T> {

    void onCallback(T object);

}
